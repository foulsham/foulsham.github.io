	  //*****************************
	  // Scanpath comparison programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

// BATCH COMPARISON GUI
/* a GUI to allow batch processing of subject files
	requires: 
		-fixationSequence.java (a class containing a series of fixations, including the distance comparison methods)
		-fixParse.java (a class for parsing a text file into several fixation sequences)
		-stringEditDistance.java (a class containing the LevensHtein string editing algorithm)
		-stringEditExtra.java (an updated string editing algorithm where the cost of each operation is weighted by the distance)
		-"/data" subdirectory for storing files
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.MouseEvent;
import javax.swing.event.*;
import java.lang.Math;

public class batchGUI implements ActionListener, ItemListener,ChangeListener
{
	static JPanel mainPanel,metricPanel,optionPanel,buttonPanel;	//creates panels
	static JLabel griddims,len,dims;	//labels to show instructions etc
    static JButton processButton,fileButton;	//buttons
    static JRadioButton dButton, mButton,uaButton,dxButton,useStrings,useCoords;	
    static JFileChooser[] fc = new JFileChooser[3];
    	File[][] files=new File[3][100];	//maximum of 100 files at a time;
    	int currentSet=0;	//integer to control the selecting of multiple input file sets
    static JCheckBox excludeFirst=new JCheckBox("Exclude first fixation");
    static JCheckBox condense=new JCheckBox("Condense consecutive fixations within the same region");
    static JCheckBox shorten=new JCheckBox("Shorten all scanpaths to specified length");
    
    //spin buttons to control the size of the grid
	static SpinnerModel modelX =new SpinnerNumberModel(5, 1, 20,1);
	static JSpinner gridXspin = new JSpinner(modelX);
	static SpinnerModel modelY =new SpinnerNumberModel(5, 1, 20,1);
	static JSpinner gridYspin = new JSpinner(modelY); 
	
	//spin buttons to control the size of the display
	static SpinnerModel modelDimX =new SpinnerNumberModel(1024, 1, 2400,1);
	static JSpinner dimXspin = new JSpinner(modelDimX);
	static SpinnerModel modelDimY =new SpinnerNumberModel(768, 1, 2400,1);
	static JSpinner dimYspin = new JSpinner(modelDimY);	
	
	//spin buttons to control the length of string to crop to (if shortener is selected)
	static SpinnerModel modelLen =new SpinnerNumberModel(5, 1, 20,1);
	static JSpinner lenSpin = new JSpinner(modelLen);
	
		
	public batchGUI()
	//CONSTRUCTOR, LAYS OUT COMPONENTS
	{
		//instantiate panels
	    mainPanel = new JPanel();
	    	mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));	
		metricPanel = new JPanel(new GridLayout());
		optionPanel = new JPanel(new GridBagLayout());
		buttonPanel = new JPanel(new GridLayout());
	    
		//add listeners to check boxes
        excludeFirst.addItemListener(this);
        	excludeFirst.setEnabled(false);
        condense.addItemListener(this);	
        	condense.setEnabled(false);
        shorten.addItemListener(this);
        	shorten.setEnabled(false);      	
        
        //instantiate buttons
        processButton = new JButton("Process all");
        fileButton = new JButton("Choose files to process"); 
        
        //add listeners to buttons
        processButton.addActionListener(this);
        processButton.setActionCommand("process");	//these are to distinguish between several events
        processButton.setEnabled(false);
        fileButton.addActionListener(this);
        fileButton.setActionCommand("filechoose");	
        fileButton.setEnabled(false);   
                
        //instantiate radio buttons
        dButton=new JRadioButton("Use Levenshtein distance");
        mButton=new JRadioButton("Use Mannan distance");
        uaButton=new JRadioButton("Use U.A. distance");
        dxButton=new JRadioButton("Use string-editing extra");    
        
        //Group the radio buttons and add listeners
        ButtonGroup modeSelectors = new ButtonGroup();
        modeSelectors.add(mButton);
        	mButton.addActionListener(this);
        	mButton.setActionCommand("mannan");
        modeSelectors.add(dButton);	
        	dButton.addActionListener(this);
        	dButton.setActionCommand("lev");        
        modeSelectors.add(uaButton);
        	uaButton.addActionListener(this);
        	uaButton.setActionCommand("ua");        
        modeSelectors.add(dxButton);
        	dxButton.addActionListener(this);
        	dxButton.setActionCommand("dx");        

        //instantiate and group radio buttons for further options
        useStrings=new JRadioButton("Text files contain strings");
        useCoords=new JRadioButton("Text files contain fixation coordinates"); 
        ButtonGroup textSelectors = new ButtonGroup();
        textSelectors.add(useStrings);
        	useStrings.addActionListener(this);
        	useStrings.setActionCommand("strings");        
        textSelectors.add(useCoords);
        	useCoords.addActionListener(this);
        	useCoords.setActionCommand("coords");          
        useStrings.setEnabled(false);
        useCoords.setEnabled(false);	  
        
        //add listeners to spin buttons
        gridXspin.addChangeListener(this);
        gridXspin.setEnabled(false);
        gridYspin.addChangeListener(this);
        gridYspin.setEnabled(false);
        lenSpin.addChangeListener(this);
        lenSpin.setEnabled(false);
        dimXspin.addChangeListener(this);
        dimXspin.setEnabled(false);
        dimYspin.addChangeListener(this);
        dimYspin.setEnabled(false);                           
        
        //instantiate labels
        griddims=new JLabel ("Use grid with these dimensions");
        dims=new JLabel ("Display has these dimensions");
        len=new JLabel ("Length");
        griddims.setEnabled(false);
        dims.setEnabled(false);
        len.setEnabled(false);
               
        //Add stuff to panels.               
        metricPanel.add(dButton);
        metricPanel.add(mButton);
        metricPanel.add(uaButton);
        metricPanel.add(dxButton);        

        //option panel requires grid bag layout for more precise arrangements
        GridBagConstraints c = new GridBagConstraints();
        c.gridx=0;
        c.gridy=0;
        c.gridwidth=3;
        c.weightx=0.4;
        c.weighty=0.3;     
        optionPanel.add(useStrings,c);
        c.gridx=3;
        optionPanel.add(useCoords,c);        
        c.gridx=0;
        c.gridy=1;
        c.gridwidth=4;
        c.weightx=0.6;     
        optionPanel.add(griddims,c);
        c.gridx=4;
        c.gridwidth=1;
        c.weightx=0.1;         
        optionPanel.add(gridXspin,c);
        c.gridx=5;
		optionPanel.add(gridYspin,c);
        c.gridx=0;
        c.gridy=2;
        c.gridwidth=4;
        c.weightx=0.6;     
        optionPanel.add(dims,c);
        c.gridx=4;
        c.gridwidth=1;
        c.weightx=0.1;         
        optionPanel.add(dimXspin,c);
        c.gridx=5;
		optionPanel.add(dimYspin,c);		
        c.gridx=0;
        c.gridy=3;
        c.gridwidth=3;
        c.weightx=0.4;		
        optionPanel.add(excludeFirst,c);
        c.gridx=3;
        optionPanel.add(condense,c);          
        c.gridx=0;
        c.gridy=4;
        c.gridwidth=2;
        c.weightx=0.4;
		optionPanel.add(shorten,c);
		c.gridx=2;	
        optionPanel.add(len,c);
        c.gridx=4;
        c.weightx=0.2;
        optionPanel.add(lenSpin,c);
        		               
        buttonPanel.add(fileButton);
        buttonPanel.add(processButton); 
        
        mainPanel.add(metricPanel);
        mainPanel.add(optionPanel);
        mainPanel.add(buttonPanel);    	
    }
        
    //METHOD REQUIRED BY THE ACTION LISTENER TRIGGERED BY BUTTON PRESS
    public void actionPerformed(ActionEvent event) 
    {
        if (event.getActionCommand().equals("filechoose"))
        //user is choosing input files
        {
	        //instantiates file chooser window which allows multiple files to be selected
	        fc[currentSet] = new JFileChooser(System.getProperty("user.dir")+File.separator+"data");
			fc[currentSet].setMultiSelectionEnabled(true);
			int returnVal = fc[currentSet].showOpenDialog(mainPanel);
			        if (returnVal == JFileChooser.APPROVE_OPTION) 
			        //user presses OK
			        {
            		files[currentSet] = fc[currentSet].getSelectedFiles();	//stores the selected files
            			if(dButton.isSelected() && useStrings.isSelected())
            			//only one set of files, each showing two columns of strings, is required	
            			{
	            		fileButton.setEnabled(false);
	            		processButton.setEnabled(true);
            			}
            			else
            			//at least two sets of coordinates required
            			{
	        				if(dxButton.isSelected() && useStrings.isSelected())
	        				//string editing extra requires two sets of coordinates plus a file showing strings
	        				{
		            			fileButton.setText("Choose paired STRINGS to process");
	            				fileButton.setEnabled(currentSet<2);
	            				processButton.setEnabled(currentSet==2);		            					        					
	        				}
	        				else
	        				//all other methods require two sets of coordinate files
	        				{
		            			fileButton.setText("Choose paired COORDINATES to process");
	            				fileButton.setEnabled(currentSet<1);
	            				processButton.setEnabled(currentSet==1);		        				
	        				}
    					}
    				currentSet++;	//ensure tracker variable is incremented to allow multiple selection windows
            		}
        
        }

	    if (event.getActionCommand().equals("process"))
	    //user ready to process input files
        {
	    mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));//show egg-timer
		RandomAccessFile fileIn,fileOut,stringFileIn;	//i/o files
		String wholeline;
		int linetracker=0;
		stringEditDistance[] myStrings;	//string edit instances
		
		//store the chosen grid / display dimensions for later
		int xnow=((SpinnerNumberModel)modelDimX).getNumber().intValue(),ynow=((SpinnerNumberModel)modelDimY).getNumber().intValue();
		int gridxnow=((SpinnerNumberModel)modelX).getNumber().intValue(),gridynow=((SpinnerNumberModel)modelY).getNumber().intValue();
		
				//now do processing for each chosen input file (e.g. each subject)
		      	for(int filenum=0;filenum<files[0].length;filenum++)
		      	{
			     System.out.println("Processing file "+(filenum+1)+" "+files[0][filenum].getName());			     
			     	
				     try	//error handling
				     {

			     	fileIn=new RandomAccessFile(files[0][filenum], "r");	//read in from here
			     	if(dxButton.isSelected()&& useStrings.isSelected()){stringFileIn=new RandomAccessFile(files[2][filenum], "r");}
			     	else{stringFileIn=new RandomAccessFile(files[0][filenum], "r");}
			     	
			     	//count the lines
			     	int linecounter=0;
			     	while (( wholeline=fileIn.readLine()) != null){linecounter++;}
			     	linetracker=linecounter;
			     	
			     	//instantiate array
			     	myStrings=new stringEditDistance[linecounter];
			     	linecounter=0;
					     				     	
					     	if(useStrings.isSelected())	
					     	//get strings from file and store them in array
					     	{
						     	
				         	while (( wholeline=stringFileIn.readLine()) != null) 
		                        //for each line in the input file
					         	{         
						         		//parse the line into two strings and store in string edit instance
								       	myStrings[linecounter]=new stringEditDistance(wholeline.substring(0,wholeline.indexOf("\t")),wholeline.substring(wholeline.indexOf("\t"),wholeline.length()));	
		                            	myStrings[linecounter].first=myStrings[linecounter].first.trim();
		                            	myStrings[linecounter].second=myStrings[linecounter].second.trim();
		                            	
		                            	if(excludeFirst.isSelected())
		                                //then remove the first character
		                            	{
		                                    myStrings[linecounter].first=(myStrings[linecounter].first.toUpperCase());	//this bit converts to caps
		                                    myStrings[linecounter].first=myStrings[linecounter].removefirstfix(myStrings[linecounter].first);	//these bits call methods
		                                    myStrings[linecounter].second=(myStrings[linecounter].second.toUpperCase());	//this bit converts to caps
		                                    myStrings[linecounter].second=myStrings[linecounter].removefirstfix(myStrings[linecounter].second);	//these bits call methods
		                                }
		        
		                                if(condense.isSelected())
		                                //then condense consecutive duplications
		                                {   
		                                    myStrings[linecounter].first=myStrings[linecounter].condenser(myStrings[linecounter].first);
		                                    myStrings[linecounter].second=myStrings[linecounter].condenser(myStrings[linecounter].second);
		                                }
		                                
		                                if(shorten.isSelected())
		                                //then crop each string to chosen length (or size of shortest string)
		                                {         
			                             	int finallength=myStrings[linecounter].findlowest(myStrings[linecounter].first.length(),myStrings[linecounter].second.length(),((SpinnerNumberModel)modelLen).getNumber().intValue());   
			                             	myStrings[linecounter].first=myStrings[linecounter].shortener(myStrings[linecounter].first,finallength);	//calls method to shorten both strings to this many chars
		                                    myStrings[linecounter].second=myStrings[linecounter].shortener(myStrings[linecounter].second,finallength);                                	
			                            }
			                    linecounter++;                        			                            
					      		}
					      	System.out.println("Strings stored from this many rows: "+linetracker);
					      	
				      	}			     	
	            	
		            	//create the output file
			            try	//error handling
						{		            			            		
					      	if(dButton.isSelected() && useStrings.isSelected())	    
					      	//standard string comparison from one file with two columns of strings     
							{
							fileOut=new RandomAccessFile("data/output"+files[0][filenum].getName(), "rw");
							     //write column headings	
							     fileOut.writeBytes("STRING_A"+"\t"+"STRING_B" +"\t"+ "EDIT_DISTANCE" +"\t" + "NORMALISED_EDIT_DISTANCE"+"\t" + "SIMILARITY"+"\n");
					            double temp=0;
					            
							    for(int spNum=0;spNum<linetracker;spNum++)
					            {	
						  			//compare the strings and write them and the similarity stats to the file
					            	temp=temp+myStrings[spNum].comparison();
					            	System.out.println(myStrings[spNum].first+"\t"+myStrings[spNum].second+"\t"+myStrings[spNum].similarity);
					            	fileOut.writeBytes(myStrings[spNum].first+"\t"+myStrings[spNum].second +"\t"+ myStrings[spNum].dist +"\t" + myStrings[spNum].normdist+"\t" + myStrings[spNum].similarity+"\n");
				            	}
				            	System.out.println("Average similarity from these files: "+(temp/linetracker));
			            			
					        }
					        
			            	else
			            	{	            							
				            fileOut=new RandomAccessFile("data/"+files[0][filenum].getName()+"_v_"+files[1][filenum].getName(), "rw");	//note output filename	
							// for all other comparisons, need to parse the coordinate files
			            
				            	//parse the first file into a set of fixation sequences
				            	fixParse firstSet=new fixParse(files[0][filenum]);
								    //an array of fixation sequences to store the scanpaths from the current files
								    fixationSequence[] firstSeq=new fixationSequence[firstSet.fixSeq.length];
								    //copy them in....
								    System.arraycopy(firstSet.fixSeq,0,firstSeq,0,firstSeq.length);		            	
			            		//parse the second file
				            	fixParse secondSet=new fixParse(files[1][filenum]);
					          		//an array of fixation sequences to store the scanpaths from the current files
								    fixationSequence[] secondSeq=new fixationSequence[secondSet.fixSeq.length];
								    //copy them in....
								    System.arraycopy(secondSet.fixSeq,0,secondSeq,0,secondSeq.length);	
								    
								//trim/shorten as necessary
								for(int spNum=0;spNum<firstSeq.length;spNum++)
			            		{
				            		if(excludeFirst.isSelected())
				            		{
					            		firstSeq[spNum].excludeFirstFixation();
					            		secondSeq[spNum].excludeFirstFixation();
					            	}					            	
	                                
	                                if(shorten.isSelected())
	                                //then crop each string to chosen length (or size of shortest string)
	                                {        
		                                myStrings[0]=new stringEditDistance("null","null");
		                                	if((firstSeq[spNum].specNum==firstSeq[spNum].startFixNum)||(secondSeq[spNum].specNum==secondSeq[spNum].startFixNum))
		                                	//Then one of the scanpaths has been reduced to zero!
		                                	{
			                                	System.out.println("ERROR! scanpath number "+(spNum+1)+" is empty in "+files[0][filenum].getName()+" or "+files[1][filenum].getName());
			                                	System.exit(0);
		                                	}
		                             	int finallength=myStrings[0].findlowest(firstSeq[spNum].specNum,secondSeq[spNum].specNum,((SpinnerNumberModel)modelLen).getNumber().intValue());   
		                             	firstSeq[spNum].specNum=finallength;	//note doesn't delete excess fixations, just changes specNum variable
	                                    secondSeq[spNum].specNum=finallength;                               	
		                            }					            	
		            			}							
								    		            
				            	if(dButton.isSelected() && useCoords.isSelected())
				            	// string editing.  This version creates the strings automatically from the coordinates and the grid / display dimensions
				            	{	
					            	//column headings
								    fileOut.writeBytes("STRING_A"+"\t"+"STRING_B" +"\t"+ "EDIT_DISTANCE" +"\t" + "NORMALISED_EDIT_DISTANCE"+"\t" + "SIMILARITY"+"\n");
								    
					            	//store the strings in an array
					            	String[] firstStrings=new String[firstSeq.length];
					            		for(int spNum=0;spNum<firstSeq.length;spNum++)
					            		{	
						            		firstStrings[spNum]=firstSeq[spNum].pointsToString(xnow,ynow,gridxnow,gridynow);
					            			//instantiate an array of edit distances
					            			myStrings[spNum]=new stringEditDistance(firstStrings[spNum],"null");
				            			}
				            			
					            	String[] secondStrings=new String[firstSeq.length];
					            	double temp=0;
					            		for(int spNum=0;spNum<firstSeq.length;spNum++)
					            		{	            	
						            	secondStrings[spNum]=secondSeq[spNum].pointsToString(xnow,ynow,gridxnow,gridynow);
					            		myStrings[spNum].second=secondStrings[spNum];
					            		
						          		if(condense.isSelected())
		                                //then condense consecutive duplications
		                                {   
		                                    myStrings[spNum].first=myStrings[spNum].condenser(myStrings[spNum].first);
		                                    myStrings[spNum].second=myStrings[spNum].condenser(myStrings[spNum].second);
		                                }
	                                				            		
					            		//compare the strings and write them and the similarity stats to the file
					            		temp=temp+myStrings[spNum].comparison();
					            		System.out.println(myStrings[spNum].first+"\t"+myStrings[spNum].second+"\t"+myStrings[spNum].similarity);
					            		fileOut.writeBytes(myStrings[spNum].first+"\t"+myStrings[spNum].second +"\t"+ myStrings[spNum].dist +"\t" + myStrings[spNum].normdist+"\t" + myStrings[spNum].similarity+"\n");
				            			}
				            		System.out.println("Average similarity from these files: "+(temp/firstSeq.length));
			            		}
		            	  
		                        
			                    if(mButton.isSelected())
				            	// mannan distance
				            	{
					            	//column headings
			                       fileOut.writeBytes("SCANPATH_A"+"\t"+"LENGTH_A" +"\t"+ "SCANPATH_B" +"\t" + "LENGTH_B"+"\t" + "D"+"\t" + "DRAND"+"\t" + "SIMILARITY_INDEX"+"\n");	
			                       double temp=0;							     
			                            for(int spNum=0;spNum<firstSeq.length;spNum++)
					            		{	
						            		temp=temp+firstSeq[spNum].fullIs(secondSeq[spNum],xnow,ynow);
			                               	fileOut.writeBytes(firstSeq[spNum].printSp()+"\t"+(firstSeq[spNum].specNum-firstSeq[spNum].startFixNum)+"\t"+secondSeq[spNum].printSp() +"\t"+ (secondSeq[spNum].specNum-secondSeq[spNum].startFixNum)+"\t"+ firstSeq[spNum].D+"\t"+ firstSeq[spNum].Drand+"\t"+ firstSeq[spNum].Is+"\n");
			                            }
			                            System.out.println("Average similarity from these files: "+(temp/firstSeq.length));		                                				                                              
			                    }
			                    
			                    if(uaButton.isSelected())
				            	// unique assignment variant
				            	{
					            	//column headings
			                       fileOut.writeBytes("SCANPATH_A"+"\t"+"LENGTH_A" +"\t"+ "SCANPATH_B" +"\t" + "LENGTH_B"+"\t" + "D"+"\t" + "DRAND"+"\t" + "UA_SIMILARITY_INDEX"+"\n");								     
			                       double temp=0;
			                       		for(int spNum=0;spNum<firstSeq.length;spNum++)
					            		{	
						            		temp=temp+firstSeq[spNum].fullUA(secondSeq[spNum],xnow,ynow);
			                               	fileOut.writeBytes(firstSeq[spNum].printSp()+"\t"+(firstSeq[spNum].specNum-firstSeq[spNum].startFixNum)+"\t"+secondSeq[spNum].printSp() +"\t"+ (secondSeq[spNum].specNum-secondSeq[spNum].startFixNum)+"\t"+ firstSeq[spNum].D+"\t"+ firstSeq[spNum].Drand+"\t"+ firstSeq[spNum].Is+"\n");
			                            }
			                            System.out.println("Average similarity from these files: "+(temp/firstSeq.length));		                                				                                              
			                    }
			                    
			                    if(dxButton.isSelected())
				            	// string editing extra
				            	{
					            	//column headings
			                       fileOut.writeBytes("STRING_A"+"\t"+"STRING_B" +"\t"+ "WEIGHTED_EDIT_DISTANCE" +"\t" + "NORMALISED_EDIT_DISTANCE"+"\t" + "WEIGHTED_SIMILARITY"+"\n");
			                       
			                       if(useStrings.isSelected())
			                       {
				                   //get strings from stored array and coords from parsed sets
				                   double temp=0;				     
			                            for(int spNum=0;spNum<firstSeq.length;spNum++)
					            		{
						            	stringEditExtra mystringEditExtra=new stringEditExtra(myStrings[spNum].first,myStrings[spNum].second,firstSeq[spNum],secondSeq[spNum],xnow,ynow);	
			                            temp=temp+mystringEditExtra.comparison();
						            	fileOut.writeBytes(mystringEditExtra.first+"\t"+mystringEditExtra.second +"\t"+ mystringEditExtra.dist +"\t" + mystringEditExtra.normdist+"\t" + mystringEditExtra.similarity+"\n");
				            			}
			                        System.out.println("Average similarity from these files: "+(temp/firstSeq.length));
		                            }
		                            
		                            if(useCoords.isSelected())
		                            {
				                   	//get coords from parsed sets and generates strings from grid
				                   	double temp=0;				     
			                            for(int spNum=0;spNum<firstSeq.length;spNum++)
					            		{
						            	stringEditExtra mystringEditExtra=new stringEditExtra(firstSeq[spNum],secondSeq[spNum],xnow,ynow,gridxnow,gridynow);	
			                            temp=temp+mystringEditExtra.comparison();
						            	fileOut.writeBytes(mystringEditExtra.first+"\t"+mystringEditExtra.second +"\t"+ mystringEditExtra.dist +"\t" + mystringEditExtra.normdist+"\t" + mystringEditExtra.similarity+"\n");
				            			}
			                        System.out.println("Average similarity from these files: "+(temp/firstSeq.length));				                            
		                            }		                                				                                              
			                    }
		                	}
			                    		                    		                    
	                	}		                        
	                    catch (IOException e) // NB remember the error handling.
			            {
			              System.out.println("An i/o error has occurred ["+e+"]");
			            }
					} 
	                catch (IOException e) // NB remember the error handling.
	                {
	                    System.out.println("An i/o error has occurred ["+e+"]");
	                }				            
			               			      	  
	         	}			
	    
	    mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));               
    	}
        
        if (event.getActionCommand().equals("lev"))
        //change the options depending on the measure selected
        {
	        excludeFirst.setEnabled(true);
	        condense.setEnabled(true);
	        fileButton.setEnabled(true);
	        shorten.setEnabled(true);
	        	shorten.setSelected(false);	        
	        len.setEnabled(true);
	        lenSpin.setEnabled(true);
	        useStrings.setEnabled(true);
	        	useStrings.setSelected(true);
	        useCoords.setEnabled(true);
	        fileButton.setText("Choose STRINGS to process");
        }
        if (event.getActionCommand().equals("strings"))
        {
	     	gridXspin.setEnabled(false);
	        gridYspin.setEnabled(false);
	        griddims.setEnabled(false);
	        dimXspin.setEnabled(false);
	        dimYspin.setEnabled(false);
	        dims.setEnabled(false);	        	        
        }
        if (event.getActionCommand().equals("coords"))
        {
	     	gridXspin.setEnabled(true);
	        gridYspin.setEnabled(true);
	        griddims.setEnabled(true);
	        dimXspin.setEnabled(true);
	        dimYspin.setEnabled(true);
	        dims.setEnabled(true);
	        fileButton.setText("Choose first COORDINATES to process");	           
        }        
        
        if (event.getActionCommand().equals("mannan"))
        {
	        excludeFirst.setEnabled(true);
	        condense.setEnabled(false);
	        fileButton.setEnabled(true);
	        shorten.setEnabled(true);
	        	shorten.setSelected(false);	        
	        gridXspin.setEnabled(false);
	        gridYspin.setEnabled(false);
	        dimXspin.setEnabled(true);
	        dimYspin.setEnabled(true);
	        dims.setEnabled(true);	        
	        griddims.setEnabled(false);
	        len.setEnabled(true);
	        lenSpin.setEnabled(true);
	        useStrings.setEnabled(false);
	        useCoords.setEnabled(false);
	        fileButton.setText("Choose first COORDINATES to process");
        }    
        
        if (event.getActionCommand().equals("ua"))
        {
	        excludeFirst.setEnabled(true);
	        condense.setEnabled(false);
	        fileButton.setEnabled(true);
	        shorten.setEnabled(true);
	        	shorten.setSelected(true);
	        gridXspin.setEnabled(false);
	        gridYspin.setEnabled(false);
	        dimXspin.setEnabled(true);
	        dimYspin.setEnabled(true);
	        dims.setEnabled(true);	        
	        griddims.setEnabled(false);
	        len.setEnabled(true);       	
	        lenSpin.setEnabled(true);
	        useStrings.setEnabled(false);
	        useCoords.setEnabled(false);
	        fileButton.setText("Choose first COORDINATES to process");
        }
        
        if (event.getActionCommand().equals("dx"))
        {
	        excludeFirst.setEnabled(true);
	        condense.setEnabled(false);
	        fileButton.setEnabled(true);
	        shorten.setEnabled(true);
	        	shorten.setSelected(false);
	        gridXspin.setEnabled(true);
	        gridYspin.setEnabled(true);
	        dimXspin.setEnabled(true);
	        dimYspin.setEnabled(true);
	        dims.setEnabled(true);		        
	        griddims.setEnabled(true);
	        len.setEnabled(true);
	        lenSpin.setEnabled(true);
	        useStrings.setEnabled(true);
	        	useStrings.setText("Choose files with corresponding strings");
	        useCoords.setEnabled(true);
	        	useCoords.setText("Generate strings using grid");
	        	useCoords.setSelected(true);
	        fileButton.setText("Choose first COORDINATES to process");
        }                          
	}    
	
    public void itemStateChanged(ItemEvent e) 
    {

    }
    
	public void stateChanged(ChangeEvent e) 
	{
		
	}    	
	    
	            
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create a new instance and so trigger constructor.
        batchGUI selector = new batchGUI();

        //Create and set up the window.
        JFrame RegionSelectorFrame = new JFrame("Scanpath batch comparison");
        RegionSelectorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        RegionSelectorFrame.setContentPane(selector.mainPanel);
        //Size and display the window.
        Insets insets = RegionSelectorFrame.getInsets();
        RegionSelectorFrame.setSize(750 + insets.left + insets.right,
                      500 + insets.top + insets.bottom);
        RegionSelectorFrame.setVisible(true);        
    }
   
     public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
