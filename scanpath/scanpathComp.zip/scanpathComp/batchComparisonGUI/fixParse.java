	  //*****************************
	  // Scanpath comparison programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

// FIXATION PARSING CLASS
//takes a series of tab delimited lines giving fix num, x and y coords

import java.io.*;
import java.awt.*;

public class fixParse 
{
	int [][] dataArray=new int [3][30100];	//this will hold all the data.  Note there is an (arbitrary) limit of 30100 fixations
	int linecounter=0;	//keep track of lines in the file
	Double temp;	//a wrapped double for parsing numbers
	static fixationSequence [] fixSeq;	//an array of fixation sequences which will hold all the scanpath information
	
	public fixParse(File file)
	//CONSTRUCTOR: opens the file and extracts the fixation data
	{
	int seqCount=0;	//keep track of number of scanpaths / sets
		try
		{
			RandomAccessFile fileIn = new RandomAccessFile(file, "r");
            //  Use the writeBytes method to write details to the file
            String wholeline;
            while (( wholeline=fileIn.readLine()) != null) 
            {        																			
	            	temp=new Double(wholeline.substring(0,wholeline.indexOf("\t")));	//NB rounds to an integer!! 
                    dataArray[0][linecounter]=temp.intValue();
                    	if(dataArray[0][linecounter]==1){seqCount++;}	//keeps track of how many sets (trials) there are
                    wholeline=wholeline.substring(wholeline.indexOf("\t"),wholeline.length());	//wholeline reset to rest of line
                    wholeline=wholeline.trim();
                    temp=new Double(wholeline.substring(0,wholeline.indexOf("\t")));    
                    dataArray[1][linecounter]=temp.intValue();
                    wholeline=wholeline.substring(wholeline.indexOf("\t"));	//wholeline reset to rest of line
                    wholeline=wholeline.trim();
                    temp=new Double(wholeline);                  
                    dataArray[2][linecounter]=temp.intValue();
                    linecounter++;	
			}
        }
                
        catch (IOException e) // NB remember the error handling.
		{
			System.out.println("An i/o error has occurred ["+e+"]");
		} 
	System.out.println(seqCount+" sets extracted from "+file.getName());
	fixSeq=new fixationSequence[seqCount];	//create the scanpath array now we know how many there are
	seqCount=-1;
	
		for(int ln=0;ln<linecounter;ln++)
		{
			if(dataArray[0][ln]==1)
			{
			//ie. when we get to new sets
			seqCount++;
				for(int f=1;f<100;f++)
				//find the end!
				{
					if((dataArray[0][ln+f]==1)||(ln+f)==linecounter)	//if new set or end of file...
					{
						fixSeq[seqCount]=new fixationSequence(dataArray[0][ln+f-1]);	//ie. sets size of scanpath
						f=100;
					}
				}						
			}
			Point tempPoint=new Point(dataArray[1][ln],dataArray[2][ln]);
			fixSeq[seqCount].addFix(tempPoint);
		}
	}

	public static void main(String[] args) 
	{

	}
}
