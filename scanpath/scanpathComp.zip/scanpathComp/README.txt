JAVA SCANPATH COMPARER

******************************************************
coded by Tom Foulsham, University of Nottingham,2007.
******************************************************

www.psychology.nottingham.ac.uk/staff/lpxtf

lpxtf@psychology.nottingham.ac.uk

*****************************************************
These programs are meant for research purposes and any and all contributions are welcome. You should check any important results and repeat or calculate by hand.  If you are planning to use them for an extended period, please contact me and let me know. 
*****************************************************


COMPILING AND RUNNING
*********************
Requires the JDK.

Unzip to the desktop.  Mac users can run the two applescript applications "LaunchGUI" and "LaunchBatchGUI" which will compile the code the first time and then run the two programs.  PC users can run the batch files with the same names.  Failing that, the programs can be compiled from the command line / terminal by changing to the directory they are in and typing "javac *java".  They can then be run by typing "java comparisonGUI" or "java batchGUI".
    
USING THE PROGRAMS
******************

***
"comparisonGUI" is a program which displays a visual area and allows two scanpaths to be selected and compared.

-select a scanpath by clicking fixation locations and then clicking "DONE".  
Alternatively, click "TYPE STRING" and enter a character string referring to a grid of regions.

-select a second scanpath in the same way.

-the two scanpaths should be displayed. You also have the option of displaying a grid and a picture behind the scanpaths.  To use your own pictures, put a valid picture file into the "/comparisonGUI/images" sub directory.

-click "COMPARE" to try out the different comparison metrics.

***
"batchGUI" is a program for performing the same comparison algorithms across many scanpaths, fed in from a text file.

-place the text files you're using in the "/data" subdirectory.

-select a comparison metric and the relevant options.

-select the input file(s).  The program is designed to process many different files (e.g. the output from many subjects).  Hold down control or apple to select multiple files.
**NB different metrics require different input files (see below)**

-click "PROCESS".  The output files will be written to the Data folder.
**NB large/many files may take a LONG time!**

THE DIFFERENT COMPARISON METHODS
********************************
Each method has different options/constraints.  Try them out on the .txt files in the "Data/Examples/" subfolder.

-String edit / Levenshtein distance (using strings)
Input: 1 set of text files, each containing just two columns of strings
Output: 1 set of output text files containing the strings compared, the distance, the distance normalised over string length, and the similarity.
Examples: "eg1_strings.txt" and "eg2_strings.txt"

-String edit / Levenshtein distance (using coordinates and a grid)
Input: 2 sets of text files, each containing 3 columns.  Each row indicates a fixation with the columns indicating fixation number, x and y.  The program parses these and compares the first sequence in the first file with the first sequence in the second file and so on.  The comparison is done by changing the coordinates to strings using the grid dimensions given.
Output: 1 set, as above (named A_v_B.txt etc.)
**NB the strings produced may differ very slightly from those calculated in excel, due to rounding differences.**
Examples: Try "eg1_coordinatesA" v "eg1_coordinatesB", "eg2_coordinatesA" v "eg2_coordinatesB" or even "eg1_coordinatesA" v "eg2_coordinatesA"!

-Mannan distance and Unique Assignment (UA) distance
Input: 2 sets of files showing fixations as above.
Output: 1 set showing the two scanpaths compared, the average normalised distance between them (D), the randomly generated distance (Drand) and the similarity index.
Examples: as above.
**NB THESE MAY TAKE A LONG TIME to compute, especially long files.  This is because for each comparison 100 random scanpaths are produced and compared (this is a compromise and it is more noisy than using 1000 simulations!)**
**NB The randomness also makes the result slightly different every time!**

-String edit extra (using coordinates and a grid)
Input: 2 sets of files showing fixations as above.
Output: 1 set showing strings and weighted edit distance.  In this version the strings are generated from a regular grid.
Examples: as above.

-String edit extra (using strings AND coordinates)
Input: *3 sets* of files. 2 showing fixations as above, the third showing the corresponding strings.
Output: 1 set showing strings and weighted edit distance.  In this version the strings are taken from the file, and the exact coordinates from the first two coordinates files.
Examples: Try using "eg1_coordinatesA", "eg1_coordinatesB" and "eg1_strings".
**This option is included for experiments where regions of interest are derived separately, but fixation information is still available**